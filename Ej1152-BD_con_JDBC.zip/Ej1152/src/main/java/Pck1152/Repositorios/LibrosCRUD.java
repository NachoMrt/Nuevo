package Pck1152.Repositorios;

import org.springframework.data.repository.CrudRepository;

import Pck1152.Entidades.Libros;

public interface LibrosCRUD extends CrudRepository<Libros, Long>{

	

}
