package Pck110.Modelo;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class IdValidator implements ConstraintValidator<IdConstraint, String>{
	
	 @Override
	  public void initialize(IdConstraint dniF) {
	  }

	  @Override
	  public boolean isValid(String idField, ConstraintValidatorContext cxt) {
	    return idField != null 
	  		  && idField.matches("[0-9]{6}[a-zA-Z]{3}");
	
	  }

	 

}
