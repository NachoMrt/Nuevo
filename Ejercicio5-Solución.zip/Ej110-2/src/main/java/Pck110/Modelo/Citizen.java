package Pck110.Modelo;

public class Citizen {

	@IdConstraint
	private String dniF;
	@PostCodeConstraint
	private String postCode;
	@IdConstraintAl
	private String dniA;
	@PostCodeConstAlm
	private String postCodeA;
	
	public Citizen () {}
	
	public Citizen(String id, String postCode) {
		this.dniF = id;	
		this.postCode = postCode;
	}

	public String getDniF() {
		return dniF;
	}

	public void setDniF(String dniF) {
		this.dniF = dniF;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getDniA() {
		return dniA;
	}

	public void setDniA(String dniA) {
		this.dniA = dniA;
	}

	public String getPostCodeA() {
		return postCodeA;
	}

	public void setPostCodeA(String postCodeA) {
		this.postCodeA = postCodeA;
	}

	@Override
	public String toString() {
		return "Citizen [dniF=" + dniF + ", postCode=" + postCode + "]";
	}
	
	
}
