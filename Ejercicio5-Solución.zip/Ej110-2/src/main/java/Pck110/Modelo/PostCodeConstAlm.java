package Pck110.Modelo;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;

@Documented
@Constraint(validatedBy = PostCodeValidatorAlm.class)
@Target( { ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface PostCodeConstAlm {

	 String message() default "Invalid PostCode Alemán";  //Mensaje que saldrá si NO se valida
	 Class<?>[] groups() default {};
	 Class<? extends Payload>[] payload() default {};
	
}
