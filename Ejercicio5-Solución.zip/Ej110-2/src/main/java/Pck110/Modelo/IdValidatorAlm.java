package Pck110.Modelo;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class IdValidatorAlm implements ConstraintValidator<IdConstraintAl, String>{

	 @Override
	  public void initialize(IdConstraintAl dniA) {
	  }

	  @Override
	  public boolean isValid(String idField, ConstraintValidatorContext cxt) {
	    return idField != null 
	  		  && idField.matches("[0-9]{7}[a-zA-Z]{2}")
	  		  && numIsCorrect(idField)
	  		  && letIsCorrect(idField);	
	  }
	  
	  private boolean numIsCorrect(String idField) {
		  int num = Integer.parseInt(idField.substring(0,6));
		  return num >= 0000000 && num <= 8888888;
	  }
	  
	  private boolean letIsCorrect(String idField) {
			char lt1 = idField.substring(7).charAt(0);
			char lt2 = idField.substring(8).charAt(0);
			boolean res = false;	
			if(Character.isUpperCase(lt1) && Character.isUpperCase(lt2)) {
				res = true;
				return res;
			};
			return res;
		}
	
}
