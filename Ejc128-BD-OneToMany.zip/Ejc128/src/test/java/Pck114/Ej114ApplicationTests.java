package Pck114;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej114ApplicationTests {

	@Test
	void contextLoads() {
	}

}
