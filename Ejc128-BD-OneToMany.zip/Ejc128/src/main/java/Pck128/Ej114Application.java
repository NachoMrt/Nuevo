package Pck128;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Transactional;

import Pck128.Entidades.Bar;
import Pck128.Entidades.Brand;
import Pck128.Entidades.License;
import Pck128.Repositorios.BarRepository;
import Pck128.Repositorios.BrandRepository;

@SpringBootApplication
public class Ej114Application implements CommandLineRunner {

	@Autowired
	BrandRepository brandRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(Ej114Application.class, args);
	}
	
	@Transactional(readOnly = true)
	@Override
	public void run(String... args) throws Exception {

		System.out.println("Showing all records");
		for (Brand brand : brandRepository.findAll()) {
			System.out.println(brand);
		}

		System.out.println("Select by name");
		for (Brand brand : brandRepository.findByName("LG")) {
			System.out.println(brand);
		}

	}

}
