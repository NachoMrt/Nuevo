package Pck128.Repositorios;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import Pck128.Entidades.Device;

import java.util.Date;
import java.util.List;
import java.util.stream.Stream;

public interface DeviceRepository extends CrudRepository<Device, Long> {

	List<Device> findByName(String name);
	
}
