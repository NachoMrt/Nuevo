insert into license (id, since, years) values (1,'2007-01-12', 5);
insert into license (id, since, years) values (2, '2008-01-12', 10);
insert into license (id, since, years) values (3, '2008-01-12', 10);

insert into bar (id, name, address) values (1, 'Bar eto', 'c/ Carrera de San Jerónimo 3');
insert into bar (id, name, address) values (2, 'Bar Mageddon', 'av/ Apocalípsis 666');
insert into bar (id, name, address) values (3, 'Bar Buerto', 'c/ Beodo 15');

insert into star (id, name, type, distance) values (1,'Antares', 4, 345234535.67);
insert into star  (id, name, type, distance)  values (2,'Sirius', 4, 546343452.16);
insert into star  (id, name, type, distance) values (3,'Vega', 2, 9895643543.89);
insert into star  (id, name, type, distance) values (4,'Sol', 3, 52342.26);

insert into planet (id, name, costelacion, distance) values (1,'Via Lactea', 'Ganimedes', 3435.67);
insert into planet  (id, name, costelacion, distance)  values (2,'Desconocida', 'JT-99', 543452.16);
insert into planet  (id, name, costelacion, distance) values (3,'Arcadia', 'XXX', 98543.89);
insert into planet  (id, name, costelacion, distance) values (4,'Nebulosa', 'Tolkien', 522.26);
