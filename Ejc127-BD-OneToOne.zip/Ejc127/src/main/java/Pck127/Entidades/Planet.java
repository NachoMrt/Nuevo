package Pck127.Entidades;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Planet {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String costelacion;
	private Double distance;
	
	public Planet(String name, String costelacion, Double distance) {
		super();
		this.name = name;
		this.costelacion = costelacion;
		this.distance = distance;
	}
	public Planet() { }
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCostelacion() {
		return costelacion;
	}
	public void setCostelacion(String costelacion) {
		this.costelacion = costelacion;
	}
	
	public Double getDistance() {
		return distance;
	}
	public void setDistance(Double distance) {
		this.distance = distance;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "Planet [id=" + id + ", name=" + name + ", costelacion=" + costelacion + ", distance=" + distance + "]";
	}
	
	
}
