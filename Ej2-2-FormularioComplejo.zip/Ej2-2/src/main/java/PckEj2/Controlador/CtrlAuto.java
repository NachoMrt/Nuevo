package PckEj2.Controlador;

import PckEj2.Modelo.Motor;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CtrlAuto {

  @GetMapping("/addmotor")
  public String nuevoMotor(Model model) {
    model.addAttribute("titulo", "Crear un motor");
    model.addAttribute("saludo", "Creando un motor");
    model.addAttribute("subsaludo", "Introduce los datos que se piden a continuación");
    Motor miMotorObjeto = new Motor();
    model.addAttribute("nuevoMotor", miMotorObjeto);
    return "automocion/motorForm";
  }

  @PostMapping("/addmotor")
  public String creadoMotor(@ModelAttribute Motor unNombreCualquiera, Model model) {
    model.addAttribute("titulo", "Motor creado");
    model.addAttribute("saludo", "Motor creado");
    model.addAttribute("subsaludo", "Verifique los datos");
    return "automocion/motorPost";
  }

}
