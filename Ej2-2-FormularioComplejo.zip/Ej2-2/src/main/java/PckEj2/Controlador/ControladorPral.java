package PckEj2.Controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ControladorPral {

  private String text1 = "Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.";
  private String text2 = "Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva";
  private String text3 = "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...";

  private String text6 = "Lorem ipsum dolor sit amet, consectetur adipisicing elit...";
  private String text5 = "Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva";
  private String text4 = "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...";

  private String text9 = "Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.";
  private String text7 = "Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva";
  private String text8 = "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...";

  private String text10 = "Lorem ipsum dolor sit amet, consectetur adipisicing elit...";
  private String text11 = "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris... Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...";
  private String text12 = "Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.";
  private String text13 = "Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva. Esperemos que funcione todo ok. Es una página web responsiva";
  private String text14 = "Aquí va el título inicial";
  private String tituloPral = "Mi hotel con Bootstrap";
  private String tituloVentana = "Mi hotel";
  private String subTituloPral = "Esperemos que funcione todo ok. Es una página web responsiva";

  @RequestMapping("/")
  public String crearPral(Model model) {
    model.addAttribute("titulo", tituloVentana);
    model.addAttribute("saludo", tituloPral);
    model.addAttribute("subsaludo", subTituloPral);

    model.addAttribute("tit1", text14);
    model.addAttribute("text1", text10);
    model.addAttribute("text2", text11);
    model.addAttribute("text3", text12);

    model.addAttribute("text4", text13);

    model.addAttribute("col1_tit", "Título Columna 1");
    model.addAttribute("col1_text1", text1);
    model.addAttribute("col1_text2", text2);
    model.addAttribute("col1_text3", text3);

    model.addAttribute("col2_tit", "Sobre la col2");
    model.addAttribute("col2_text1", text4);
    model.addAttribute("col2_text2", text5);
    model.addAttribute("col2_text3", text6);

    model.addAttribute("col3_tit", "Otra columna 3");
    model.addAttribute("col3_text1", text7);
    model.addAttribute("col3_text2", text8);
    model.addAttribute("col3_text3", text9);

    return "index";
  }

  @GetMapping("/say")
  public String saySomething(@RequestParam(value = "something", required = false, defaultValue = "Hello") String something, Model model) {
    model.addAttribute("titulo", tituloVentana);
    model.addAttribute("saludo", tituloPral);
    model.addAttribute("subsaludo", subTituloPral);
    model.addAttribute("tit1", "El parámetro pasado como something ha sido: " + something);

    model.addAttribute("col1_tit", "Título Columna 1");
    model.addAttribute("col1_text1", text1);
    model.addAttribute("col1_text2", text2);
    model.addAttribute("col1_text3", text3);

    model.addAttribute("col2_tit", "Sobre la col2");
    model.addAttribute("col2_text1", text4);
    model.addAttribute("col2_text2", text5);
    model.addAttribute("col2_text3", text6);

    model.addAttribute("col3_tit", "Otra columna 3");
    model.addAttribute("col3_text1", text7);
    model.addAttribute("col3_text2", text8);
    model.addAttribute("col3_text3", text9);
    return "index";
  }

  @GetMapping("/nombre/{name}/Edad/{edad}")
  public String mandarPath(@PathVariable String name, @PathVariable int edad, Model model) {
    model.addAttribute("titulo", tituloVentana);
    model.addAttribute("saludo", tituloPral);
    model.addAttribute("subsaludo", subTituloPral);
    model.addAttribute("tit1", "El parámetro pasado como name ha sido: " + name + " Edad: " + edad);

    model.addAttribute("col1_tit", "Título Columna 1");
    model.addAttribute("col1_text1", text1);
    model.addAttribute("col1_text2", text2);
    model.addAttribute("col1_text3", text3);

    model.addAttribute("col2_tit", "Sobre la col2");
    model.addAttribute("col2_text1", text4);
    model.addAttribute("col2_text2", text5);
    model.addAttribute("col2_text3", text6);

    model.addAttribute("col3_tit", "Otra columna 3");
    model.addAttribute("col3_text1", text7);
    model.addAttribute("col3_text2", text8);
    model.addAttribute("col3_text3", text9);
    return "index";
  }

  @GetMapping("/sumar")
  public String add(@RequestParam(value = "a", required = true, defaultValue = "0") Integer a,
          @RequestParam(value = "b", required = true, defaultValue = "0") Integer b,
          Model model) {
    int result = a + b;
    model.addAttribute("titulo", tituloVentana);
    model.addAttribute("saludo", tituloPral);
    model.addAttribute("subsaludo", subTituloPral);
    model.addAttribute("tit1", "He hecho una suma recibiendo dos parámetros");
    model.addAttribute("text1", "Se ha realizado la suma de " + a + " + " + b);
    model.addAttribute("text2", "El resultado ha sido: " + result);

    model.addAttribute("col1_tit", "Título Columna 1");
    model.addAttribute("col1_text1", text1);
    model.addAttribute("col1_text2", text2);
    model.addAttribute("col1_text3", text3);

    model.addAttribute("col2_tit", "Sobre la col2");
    model.addAttribute("col2_text1", text4);
    model.addAttribute("col2_text2", text5);
    model.addAttribute("col2_text3", text6);

    model.addAttribute("col3_tit", "Otra columna 3");
    model.addAttribute("col3_text1", text7);
    model.addAttribute("col3_text2", text8);
    model.addAttribute("col3_text3", text9);
    return "index";
  }

  @GetMapping("/multiplicar/{a}/{b}")
  public String multi(@PathVariable int a, @PathVariable int b, Model model) {
    int result = a * b;
    model.addAttribute("titulo", tituloVentana);
    model.addAttribute("saludo", tituloPral);
    model.addAttribute("subsaludo", subTituloPral);
    model.addAttribute("tit1", "He hecho una multiplicación recibiendo dos parámetros");
    model.addAttribute("text1", "Se ha realizado la multiplicación de " + a + " * " + b);
    model.addAttribute("text2", "El resultado ha sido: " + result);

    model.addAttribute("col1_tit", "Título Columna 1");
    model.addAttribute("col1_text1", text1);
    model.addAttribute("col1_text2", text2);
    model.addAttribute("col1_text3", text3);

    model.addAttribute("col2_tit", "Sobre la col2");
    model.addAttribute("col2_text1", text4);
    model.addAttribute("col2_text2", text5);
    model.addAttribute("col2_text3", text6);

    model.addAttribute("col3_tit", "Otra columna 3");
    model.addAttribute("col3_text1", text7);
    model.addAttribute("col3_text2", text8);
    model.addAttribute("col3_text3", text9);
    return "index";
  }
}
