package PckEj2.Controlador;

import PckEj2.Modelo.Clientevip;
import PckEj2.Modelo.Reserva;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class CtrlHotel {

  @GetMapping("/reserva")
  public String reservaIntroduce(Model model) {
    model.addAttribute("titulo", "Haciendo una reserva");
    model.addAttribute("saludo", "Haciendo una reserva");
    model.addAttribute("subsaludo", "Introduce los datos que se piden a continuación");
    Reserva miReservaObjeto = new Reserva();
    miReservaObjeto.setRadioOpcion(3);
    model.addAttribute("reservaSpring", miReservaObjeto);
    return "hotel/reserva";
  }

  @PostMapping("/reserva")
  public String greetingSubmit(@ModelAttribute Reserva unNombreCualquiera, Model model) {
    model.addAttribute("titulo", "Reserva realizada");
    model.addAttribute("saludo", "Reserva realizada");
    model.addAttribute("subsaludo", "Verifique los datos");
    return "hotel/reservaRealizada";
  }

  @GetMapping("/clientevip")
  public String clienteIntroduce(Model model) {
    model.addAttribute("titulo", "Haciendo un cliente VIP");
    model.addAttribute("saludo", "cliente VIP");
    model.addAttribute("subsaludo", "Introduce los datos que se piden a continuación");
    Clientevip miClienteVIP = new Clientevip();
    model.addAttribute("clienteVIP", miClienteVIP);
    return "hotel/clientevipform";
  }

  @PostMapping("/clientevip")
  public String clienteMetido(@ModelAttribute Clientevip unNombreCualquiera, Model model) {
    model.addAttribute("titulo", "cliente VIP realizado");
    model.addAttribute("saludo", "cliente VIP realizado");
    model.addAttribute("subsaludo", "Verifique los datos");
    return "hotel/clientevip";
  }
}
