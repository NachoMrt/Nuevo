package PckEj2.Modelo;

import lombok.Data;

public @Data class Motor {

  private String id;
  private String tipo;
  private String combustible;
  private int potencia;
  private int cilindrada;
  private int cantidadCilindros;
  private boolean turbo;
  private boolean intercooler;
  private boolean carburador;
  private String fechaCreacion;
  private String descripcion;
  private int valvulas;

}
