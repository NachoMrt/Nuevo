package PckEj2.Modelo;

public class Reserva {

  private String nombre;
  private String apellido;
  private String dni;
  private int edad;
  private String nombre2;
  private String apellido2;
  private String dni2;
  private int edad2;
  private String entrada;
  private String salida;
  private boolean compa;
  private int radioOpcion;
  private String mascota;

  public String getEntrada() {
    return entrada;
  }

  public void setEntrada(String entrada) {
    this.entrada = entrada;
  }

  public String getSalida() {
    return salida;
  }

  public void setSalida(String salida) {
    this.salida = salida;
  }

  public Reserva() {
  }

  public int getEdad() {
    return edad;
  }

  public void setEdad(int edad) {
    this.edad = edad;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getApellido() {
    return apellido;
  }

  public void setApellido(String apellido) {
    this.apellido = apellido;
  }

  public String getDni() {
    return dni;
  }

  public void setDni(String dni) {
    this.dni = dni;
  }

  @Override
  public String toString() {
    return "Reserva{" + "nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni + ", edad=" + edad + '}';
  }

  public String getNombre2() {
    return nombre2;
  }

  public void setNombre2(String nombre2) {
    this.nombre2 = nombre2;
  }

  public String getApellido2() {
    return apellido2;
  }

  public void setApellido2(String apellido2) {
    this.apellido2 = apellido2;
  }

  public String getDni2() {
    return dni2;
  }

  public void setDni2(String dni2) {
    this.dni2 = dni2;
  }

  public int getEdad2() {
    return edad2;
  }

  public void setEdad2(int edad2) {
    this.edad2 = edad2;
  }

  public boolean isCompa() {
    return compa;
  }

  public void setCompa(boolean compa) {
    this.compa = compa;
  }

  public int getRadioOpcion() {
    return radioOpcion;
  }

  public void setRadioOpcion(int radioOpcion) {
    this.radioOpcion = radioOpcion;
  }

  public String getMascota() {
    return mascota;
  }

  public void setMascota(String mascota) {
    this.mascota = mascota;
  }
}
