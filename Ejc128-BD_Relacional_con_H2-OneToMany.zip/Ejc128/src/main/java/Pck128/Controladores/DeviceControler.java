package Pck128.Controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import Pck128.Entidades.Device;
import Pck128.Repositorios.DeviceRepository;

@Controller
public class DeviceControler {
	
	@Autowired
	private DeviceRepository dveRp;
	
	@RequestMapping("/devices")
	public String read(Model model) {
		model.addAttribute("devices", dveRp.findAll());
		return "device/devices";
	}
	
	@RequestMapping("/devices/create")
	public String create(Model model) {
		model.addAttribute("device", new Device());
		return "/device/createDv";
	}

	@PostMapping("/devices/create")
	public String saveCreate(Device device) {
		System.out.println("Saving Divece: " + device);
		dveRp.save(device);
		return "forward:/devices"; // Forward happens on the server			
	}

	@RequestMapping("/devices/{id}")
	public String show(@PathVariable("id") Long id, Model model) {
		//model.addAttribute("planet",starsRepository.findById(id));
		dveRp.findById(id).ifPresent(o -> model.addAttribute("device", o));
		return "device/detailDv";
	}
	
	@RequestMapping("/devices/update/{id}")
	public String update(@PathVariable("id") Long id, Model model) {
		model.addAttribute("device", dveRp.findById(id));
		return "/device/updateDv";
	}

	@PostMapping("/devices/update")
	public String saveUpdate(Device device) {
		System.out.println("Updating device: " + device);
		dveRp.save(device);
		return "forward:/devices"; // Forward happens on the server
	}
	
	@RequestMapping("/devices/delete/{id}")
	public String delete(@PathVariable("id") Long id, Model model) {
		dveRp.deleteById(id);
		return "forward:/devices"; // Forward happens on the server
	}
 	


}
