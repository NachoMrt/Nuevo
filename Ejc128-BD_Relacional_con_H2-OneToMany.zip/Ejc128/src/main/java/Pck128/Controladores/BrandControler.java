package Pck128.Controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import Pck128.Entidades.Brand;
import Pck128.Repositorios.BrandRepository;

@Controller
public class BrandControler {
	
	@Autowired
	private BrandRepository brdRp;
	
	@RequestMapping("/brands")
	public String read(Model model) {
		model.addAttribute("brands", brdRp.findAll());
		return "brand/brands";
	}
	
	@RequestMapping("/brands/create")
	public String create(Model model) {
		model.addAttribute("brand", new Brand());
		return "/brand/createBrd";
	}

	@PostMapping("/brands/create")
	public String saveCreate(Brand brand) {
		System.out.println("Saving Brand: " + brand);
		brdRp.save(brand);
		return "forward:/brands"; // Forward happens on the server
	}

	@RequestMapping("/brands/{id}")
	public String show(@PathVariable("id") Long id, Model model) {
		//model.addAttribute("planet",starsRepository.findById(id));
		brdRp.findById(id).ifPresent(o -> model.addAttribute("brand", o));
		return "brand/detailBrd";
	}
	
	@RequestMapping("/brands/update/{id}")
	public String update(@PathVariable("id") Long id, Model model) {
		model.addAttribute("brand", brdRp.findById(id));
		return "/brand/updateBrd";
	}

	@PostMapping("/brands/update")
	public String saveUpdate(Brand brand) {
		System.out.println("Updating brand: " + brand);
		brdRp.save(brand);
		return "forward:/brands"; // Forward happens on the server
	}
	
	@RequestMapping("/brands/delete/{id}")
	public String delete(@PathVariable("id") Long id, Model model) {
		brdRp.deleteById(id);
		return "forward:/brands"; // Forward happens on the server
	}
 	


}
