package Pck128.Controladores;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import Pck128.Entidades.Planet;
import Pck128.Repositorios.PlanetRepository;

@Controller
public class PlanetController {

	@Autowired
	private PlanetRepository planetRepository;

	@RequestMapping("/planets")
	public String read(Model model) {
		model.addAttribute("planetas", planetRepository.findAll());
		return "readPl";
	}

	@RequestMapping("/planets/{id}")
	public String show(@PathVariable("id") Long id, Model model) {
		//model.addAttribute("planet",starsRepository.findById(id));
		planetRepository.findById(id).ifPresent(o -> model.addAttribute("planet", o));
		return "detailPl";
	}

	@RequestMapping("/planets/delete/{id}")
	public String delete(@PathVariable("id") Long id, Model model) {
		planetRepository.deleteById(id);
		return "forward:/planets"; // Forward happens on the server
	}

	@RequestMapping("/planets/create")
	public String create(Model model) {
		model.addAttribute("planet", new Planet());
		return "createPl";
	}

	@PostMapping("/planets/create")
	public String saveCreate(Planet planet) {
		System.out.println("Saving Planeta: " + planet);
		planetRepository.save(planet);
		return "forward:/planets"; // Forward happens on the server
	}

	@RequestMapping("/planets/update/{id}")
	public String update(@PathVariable("id") Long id, Model model) {
		model.addAttribute("planet", planetRepository.findById(id));
		return "updatePl";
	}

	@PostMapping("/planets/update")
	public String saveUpdate(Planet planet) {
		System.out.println("Updating star: " + planet);
		planetRepository.save(planet);
		return "forward:/planets"; // Forward happens on the server
	}
	    	
}
