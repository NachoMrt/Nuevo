package Pck128.Repositorios;

import org.springframework.data.repository.CrudRepository;

import Pck128.Entidades.Bar;
import Pck128.Entidades.License;

import java.util.List;

public interface BarRepository extends CrudRepository<Bar, Long> {

	List<Bar> findByName(String name);
	List<Bar> findByAddress(String address);
	Bar findByLicense(License license);
	
}
