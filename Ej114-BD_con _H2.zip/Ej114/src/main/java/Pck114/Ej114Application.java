package Pck114;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej114Application {

	public static void main(String[] args) {
		SpringApplication.run(Ej114Application.class, args);
	}

}
