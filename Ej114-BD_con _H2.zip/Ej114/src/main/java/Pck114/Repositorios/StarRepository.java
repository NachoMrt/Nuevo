package Pck114.Repositorios;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import Pck114.Entidades.Star;
import java.util.List;

public interface StarRepository extends CrudRepository<Star, Long>{

	List<Star> findByName(String name);
	
}
