insert into star (id, name, type, distance) values (1,'Antares', 4, 345234535.67);
insert into star  (id, name, type, distance)  values (2,'Sirius', 4, 546343452.16);
insert into star  (id, name, type, distance) values (3,'Vega', 2, 9895643543.89);
insert into star  (id, name, type, distance) values (4,'Sol', 3, 52342.26);

insert into planet (id, name, costelacion, distance) values (1,'Via Lactea', 'Ganimedes', 3435.67);
insert into planet  (id, name, costelacion, distance)  values (2,'Desconocida', 'JT-99', 543452.16);
insert into planet  (id, name, costelacion, distance) values (3,'Arcadia', 'XXX', 98543.89);
insert into planet  (id, name, costelacion, distance) values (4,'Nebulosa', 'Tolkien', 522.26);