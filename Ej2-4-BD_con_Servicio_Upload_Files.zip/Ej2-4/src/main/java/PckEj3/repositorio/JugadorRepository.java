package PckEj3.repositorio;

import PckEj3.entidad.Jugador;
import java.util.List;
import org.springframework.data.repository.CrudRepository;

public interface JugadorRepository extends CrudRepository<Jugador, Long> {

 // List<Jugador> findByName(String name);

}
