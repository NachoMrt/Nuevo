package PckEj3.repositorio;

import PckEj3.entidad.Alumno;
import org.springframework.data.repository.CrudRepository;

public interface AlumnoRepository extends CrudRepository<Alumno, Long> {


}
