package PckEj3.Controlador;

import PckEj3.Servicio.FilesUpload;
import java.io.IOException;
import org.apache.tomcat.util.http.fileupload.impl.FileSizeLimitExceededException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class CtrlSubirArchivo {

  @Autowired
  private FilesUpload uploadFileService;

  @RequestMapping("/public/upload")
  public String subirArchivo(Model model) {
    model.addAttribute("tituloWeb", "Subir archivo");
    model.addAttribute("titulo", "Subir archivo");
    model.addAttribute("subtitulo", "Subir archivo del ejercicio 115");
    return "/ej115/subir";
  }

  @PostMapping("/public/upload")
  public String uploadFile(@RequestParam("file") MultipartFile file, Model model) {
    if (file.isEmpty()) {
      model.addAttribute("error", true);
      model.addAttribute("tituloWeb", "Subir archivo");
      model.addAttribute("titulo", "Subir archivo");
      model.addAttribute("subtitulo", "Subir archivo del ejercicio 115. No había archivo");
      return "/ej115/subir";
    }

    try {
      uploadFileService.saveFile(file);
    } catch (FileSizeLimitExceededException e) {
      e.printStackTrace();
      model.addAttribute("error", true);
      model.addAttribute("tituloWeb", "Subir archivo");
      model.addAttribute("titulo", "Subir archivo");
      model.addAttribute("subtitulo", "Subir archivo del ejercicio 115. El archivo era demasiado grande");
      return "/ej115/subir";
    } catch (IOException e) {
      e.printStackTrace();
      model.addAttribute("error", true);
      model.addAttribute("tituloWeb", "Subir archivo");
      model.addAttribute("titulo", "Subir archivo");
      model.addAttribute("subtitulo", "Subir archivo del ejercicio 115");
      return "/ej115/subir";
    }

    model.addAttribute("tituloWeb", "Subir archivo");
    model.addAttribute("titulo", "Subir archivo");
    model.addAttribute("subtitulo", "Subir archivo del ejercicio 115");

    model.addAttribute("subido", true);

    return "/ej115/subir";
  }
}
