package PckEj3.Controlador;

import PckEj3.entidad.Jugador;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import PckEj3.repositorio.JugadorRepository;
import javax.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class JugadorController {

  @Autowired
  private JugadorRepository jugadorRepository;

  @RequestMapping("/public/jugadores")
  public String read(Model model) {
    model.addAttribute("tituloWeb", "Ver jugadores");
    model.addAttribute("titulo", "Ver jugadores");
    model.addAttribute("subtitulo", "Mostrando listado de jugadores de la BBDD");
    model.addAttribute("jugadores", jugadorRepository.findAll());
    return "/ej115/jugador/read";
  }

  @RequestMapping("/public/jugadores/{dorsal}")
  public String show(@PathVariable("dorsal") Long dorsal, Model model) {
    model.addAttribute("tituloWeb", "Ver jugador");
    model.addAttribute("titulo", "Ver jugador");
    model.addAttribute("subtitulo", "Mostrando jugador concreto de la BBDD");
    jugadorRepository.findById(dorsal).ifPresent(o -> model.addAttribute("jugador", o));
    return "/ej115/jugador/detail";
  }

  @RequestMapping("/public/jugadores/delete/{dorsal}")
  public String delete(@PathVariable("dorsal") Long dorsal, Model model) {
    jugadorRepository.deleteById(dorsal);
    model.addAttribute("tituloWeb", "Elimina jugador");
    model.addAttribute("titulo", "Elimina jugador");
    model.addAttribute("subtitulo", "Eliminado jugador concreto de la BBDD");
    model.addAttribute("jugadores", jugadorRepository.findAll());
    model.addAttribute("eliminado", true);
    return "/ej115/jugador/read";
  }

  @GetMapping("/public/jugadores/create")
  public String create(Model model) {
    model.addAttribute("tituloWeb", "Crear jugador");
    model.addAttribute("titulo", "Crear jugador");
    model.addAttribute("subtitulo", "Creando jugador en la BBDD");
    model.addAttribute("jugador", new Jugador());
    model.addAttribute("postForm", "/public/jugadores/create");
    return "/ej115/jugador/create";
  }

  @PostMapping("/public/jugadores/create")
  public String saveCreate(@Valid @ModelAttribute("jugador") Jugador jugador, BindingResult bindingResult, Model model) {

    if (bindingResult.hasErrors()) {
      System.out.println("Errores en la validación: " + bindingResult.getAllErrors());
      model.addAttribute("error", true);
      model.addAttribute("tituloWeb", "Crear jugador");
      model.addAttribute("titulo", "Crear jugador");
      model.addAttribute("subtitulo", "Creando jugador en la BBDD");
      model.addAttribute("postForm", "/public/jugadores/create");
      return "/ej115/jugador/create";
    }

    model.addAttribute("tituloWeb", "Crear jugador");
    model.addAttribute("titulo", "Crear jugador");
    model.addAttribute("subtitulo", "Creado jugador en la BBDD");
    System.out.println("Saving jugador: " + jugador);
    model.addAttribute("creado", true);
    jugadorRepository.save(jugador);
    model.addAttribute("jugadores", jugadorRepository.findAll());
    return "/ej115/jugador/read";
  }

  @RequestMapping("/public/jugadores/update/{dorsal}")
  public String update(@PathVariable("dorsal") Long dorsal, Model model) {
    String ruta;
    ruta = "/public/jugadores/update/" + dorsal;
    model.addAttribute("tituloWeb", "Actualizar jugador");
    model.addAttribute("titulo", "Actualizar jugador");
    model.addAttribute("subtitulo", "Actualizando jugador en la BBDD");
    model.addAttribute("postForm", ruta);
    model.addAttribute("jugador", jugadorRepository.findById(dorsal));
    model.addAttribute("actualizando", true);
    return "/ej115/jugador/create";
  }

  @PostMapping("/public/jugadores/update/{dorsal}")
  public String saveUpdate(@PathVariable("dorsal") Long dorsal, @Valid @ModelAttribute("jugador") Jugador jugador, BindingResult bindingResult, Model model) {
    String ruta;
    ruta = "/public/jugadores/update/" + dorsal;

    if (bindingResult.hasErrors()) {
      System.out.println("Errores en la validación: " + bindingResult.getAllErrors());
      model.addAttribute("error", true);
      model.addAttribute("tituloWeb", "Crear jugador");
      model.addAttribute("titulo", "Crear jugador");
      model.addAttribute("subtitulo", "Creando jugador en la BBDD");
      model.addAttribute("actualizando", true);
      model.addAttribute("jugador", jugador);
      model.addAttribute("postForm", ruta);
      return "/ej115/jugador/create";
    }

    model.addAttribute("tituloWeb", "Actualizar jugador");
    model.addAttribute("titulo", "Actualizar jugador");
    model.addAttribute("subtitulo", "Actualizado jugador en la BBDD");
    System.out.println("Updating jugador: " + jugador);
    jugadorRepository.save(jugador);
    model.addAttribute("jugadores", jugadorRepository.findAll());
    model.addAttribute("actualizado", true);
    return "/ej115/jugador/read";
  }

}
