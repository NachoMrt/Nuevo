package PckEj3.Controlador;
import PckEj3.repositorio.AlumnoRepository;
import PckEj3.entidad.Alumno;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class AlumnoController {

  @Autowired
  private AlumnoRepository alumnoRepositorio;

  @RequestMapping("/public/alumnos")
  public String read(Model model) {
    model.addAttribute("tituloWeb", "Ver alumnos");
    model.addAttribute("titulo", "Ver alumnos");
    model.addAttribute("subtitulo", "Mostrando listado de alumnos de la BBDD");
    model.addAttribute("alumnos", alumnoRepositorio.findAll());
    return "/ej115/alumno/read";
  }

  @RequestMapping("/public/alumnos/{id}")
  public String show(@PathVariable("id") Long id, Model model) {
    model.addAttribute("tituloWeb", "Ver alumno");
    model.addAttribute("titulo", "Ver alumno");
    model.addAttribute("subtitulo", "Mostrando alumno concreto de la BBDD");
    alumnoRepositorio.findById(id).ifPresent(o -> model.addAttribute("alumno", o));
    return "/ej115/alumno/detail";
  }

  @RequestMapping("/public/alumnos/delete/{id}")
  public String delete(@PathVariable("id") Long id, Model model) {
    alumnoRepositorio.deleteById(id);
    model.addAttribute("tituloWeb", "Elimina alumno");
    model.addAttribute("titulo", "Elimina alumno");
    model.addAttribute("subtitulo", "Eliminado alumno concreto de la BBDD");
    model.addAttribute("alumnos", alumnoRepositorio.findAll());
    model.addAttribute("eliminado", true);
    return "/ej115/alumno/read";
  }

  @GetMapping("/public/alumnos/create")
  public String create(Model model) {
    model.addAttribute("tituloWeb", "Crear alumno");
    model.addAttribute("titulo", "Crear alumno");
    model.addAttribute("subtitulo", "Creando alumno en la BBDD");
    model.addAttribute("alumno", new Alumno());
    model.addAttribute("postForm", "/public/alumnos/create");
    return "/ej115/alumno/create";
  }

  @PostMapping("/public/alumnos/create")
  public String saveCreate(@Valid @ModelAttribute("alumno") Alumno alumno, BindingResult bindingResult, Model model) {

    if (bindingResult.hasErrors()) {
      System.out.println("Errores en la validación: " + bindingResult.getAllErrors());
      model.addAttribute("error", true);
      model.addAttribute("tituloWeb", "Crear alumno");
      model.addAttribute("titulo", "Crear alumno");
      model.addAttribute("subtitulo", "Creando alumno en la BBDD");
      model.addAttribute("postForm", "/public/alumnos/create");
      return "/ej115/alumno/create";
    }

    model.addAttribute("tituloWeb", "Crear alumno");
    model.addAttribute("titulo", "Crear alumno");
    model.addAttribute("subtitulo", "Creado alumno en la BBDD");
    System.out.println("Saving alumno: " + alumno);
    model.addAttribute("creado", true);
    alumnoRepositorio.save(alumno);
    model.addAttribute("alumnos", alumnoRepositorio.findAll());
    return "/ej115/alumno/read";
  }

  @RequestMapping("/public/alumnos/update/{id}")
  public String update(@PathVariable("id") Long id, Model model) {
    String ruta;
    ruta = "/public/alumnos/update/" + id;
    model.addAttribute("tituloWeb", "Actualizar alumno");
    model.addAttribute("titulo", "Actualizar alumno");
    model.addAttribute("subtitulo", "Actualizando alumno en la BBDD");
    model.addAttribute("postForm", ruta);
    model.addAttribute("alumno", alumnoRepositorio.findById(id));
    model.addAttribute("actualizando", true);
    return "/ej115/alumno/create";
  }

  @PostMapping("/public/alumnos/update/{id}")
  public String saveUpdate(@PathVariable("id") Long id, @Valid @ModelAttribute("alumno") Alumno alumno, BindingResult bindingResult, Model model) {
    String ruta;
    ruta = "/public/alumnos/update/" + id;

    if (bindingResult.hasErrors()) {
      System.out.println("Errores en la validación: " + bindingResult.getAllErrors());
      model.addAttribute("error", true);
      model.addAttribute("tituloWeb", "Crear alumno");
      model.addAttribute("titulo", "Crear alumno");
      model.addAttribute("subtitulo", "Creando alumno en la BBDD");
      model.addAttribute("alumno", alumno);
      model.addAttribute("actualizando", true);
      model.addAttribute("postForm", ruta);
      return "/ej115/alumno/create";
    }

    model.addAttribute("tituloWeb", "Actualizar alumno");
    model.addAttribute("titulo", "Actualizar alumno");
    model.addAttribute("subtitulo", "Actualizado alumno en la BBDD");
    System.out.println("Updating alumno: " + alumno);
    alumnoRepositorio.save(alumno);
    model.addAttribute("alumnos", alumnoRepositorio.findAll());
    model.addAttribute("actualizado", true);
    return "/ej115/alumno/read";
  }

}
