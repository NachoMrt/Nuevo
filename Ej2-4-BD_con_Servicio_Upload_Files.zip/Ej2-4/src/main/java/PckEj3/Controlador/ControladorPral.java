package PckEj3.Controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ControladorPral {

  @RequestMapping("/")
  public String crearPral(Model model) {
    model.addAttribute("tituloWeb", "Página principal");
    model.addAttribute("titulo", "Bienvenido");
    model.addAttribute("subtitulo", "Página principal del ejercicio 115");
    return "/ej115/index";
  }
}
