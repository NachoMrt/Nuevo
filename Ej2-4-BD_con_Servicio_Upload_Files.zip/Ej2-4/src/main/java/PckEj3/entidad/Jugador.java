package PckEj3.entidad;

import PckEj3.Modelo.validadorPersonal.FechaConstraint;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import lombok.Data;

@Entity
public @Data
class Jugador {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Min(1)
  private Long dorsal;

  @Size(min = 2, max = 60)
  private String nombre;

  @Size(min = 2, max = 60, message = "Debe elegir una posición")
  private String posicion;

  @Size(min = 2, max = 60, message = "Debe elegir un equipo")
  private String equipo;

  @FechaConstraint
  private String fechanacimiento;

  
  public Jugador(@Min(1) Long dorsal, @Size(min = 2, max = 60) String nombre,
		@Size(min = 2, max = 60, message = "Debe elegir una posición") String posicion,
		@Size(min = 2, max = 60, message = "Debe elegir un equipo") String equipo, String fechanacimiento) {
	super();
	this.dorsal = dorsal;
	this.nombre = nombre;
	this.posicion = posicion;
	this.equipo = equipo;
	this.fechanacimiento = fechanacimiento;
  }
  
  public Jugador() { super(); }

  public Long getDorsal() {
	return dorsal;
  }
  
  public void setDorsal(Long dr) {
	this.dorsal = dr;
  }

  public String getNombre() {
	return nombre;
  }

  public void setNombre(String nombre) {
	this.nombre = nombre;
  }

  public String getPosicion() {
	return posicion;
  }

  public void setPosicion(String posicion) {
	this.posicion = posicion;
  }

  public String getEquipo() {
	return equipo;
  }

  public void setEquipo(String equipo) {
	this.equipo = equipo;
  }

  public String getFechanacimiento() {
	return fechanacimiento;
  }

  public void setFechanacimiento(String fechanacimiento) {
	this.fechanacimiento = fechanacimiento;
  }
  
  
}
