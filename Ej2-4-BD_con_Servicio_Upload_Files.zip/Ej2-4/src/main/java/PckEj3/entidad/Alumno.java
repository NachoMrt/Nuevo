package PckEj3.entidad;

import PckEj3.Modelo.validadorPersonal.FechaConstraint;
import PckEj3.Modelo.validadorPersonal.DniSpainConstraint;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import lombok.Data;

@Entity
public @Data class Alumno {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Size(min = 2, max = 30)
  private String nombre;

  @Size(min = 2, max = 60)
  private String apellido;

  @Size(min = 2, max = 500)
  private String observacion;

  @Min(value = 1, message = "La nota debe ser mayor que 0")
  @Max(value = 10, message = "La nota debe ser menor o igual que 10")
  private int nota;

  @DniSpainConstraint
  private String dni;

  @FechaConstraint
  private String fechanacimiento;

  public Alumno(Long id, @Size(min = 2, max = 30) String nombre, @Size(min = 2, max = 60) String apellido,
		@Size(min = 2, max = 500) String observacion,
		@Min(value = 1, message = "La nota debe ser mayor que 0") @Max(value = 10, message = "La nota debe ser menor o igual que 10") int nota,
		String dni, String fechanacimiento) {
	super();
	this.id = id;
	this.nombre = nombre;
	this.apellido = apellido;
	this.observacion = observacion;
	this.nota = nota;
	this.dni = dni;
	this.fechanacimiento = fechanacimiento;
  }
  
  public Alumno() { super(); }

  public Long getId() {
	return id;
  }
  public void setId(Long d) {
    this.id = d;;
  }

  public String getNombre() {
	return nombre;
  }

  public void setNombre(String nombre) {
	this.nombre = nombre;
  }

  public String getApellido() {
	return apellido;
  }

  public void setApellido(String apellido) {
	this.apellido = apellido;
  }

  public String getObservacion() {
	return observacion;
  }

  public void setObservacion(String observacion) {
	this.observacion = observacion;
  }

  public int getNota() {
	return nota;
  }

  public void setNota(int nota) {
	this.nota = nota;
  }

  public String getDni() {
	return dni;
  }

  public void setDni(String dni) {
	this.dni = dni;
  }

  public String getFechanacimiento() {
	return fechanacimiento;
  }

  public void setFechanacimiento(String fechanacimiento) {
	this.fechanacimiento = fechanacimiento;
  }
  
  
  
  
}
