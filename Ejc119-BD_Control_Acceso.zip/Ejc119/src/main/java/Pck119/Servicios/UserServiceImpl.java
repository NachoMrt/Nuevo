package Pck119.Servicios;

import java.util.Arrays;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import Pck119.Entidades.Role;
import Pck119.Entidades.User;
import Pck119.Repositorios.RoleRepository;
import Pck119.Repositorios.UserRepository;
import Pck119.Seguridad.LamePasswordEncoder;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
    private RoleRepository roleRepository;
    @Autowired
    private LamePasswordEncoder lamePasswordEncoder;
	
	public User findUserByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	public User findUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}
	
	public void saveUser(User user) {  // Lo guarda como "ADMIN"
		user.setPassword(lamePasswordEncoder.encode(user.getPassword()));  // password
        user.setEnabled(true);  // pone propiedad enabled a true
        
        Role userAdminRole = roleRepository.findByRole("ADMIN");  // Busca rol "ADMIN"
        user.setRoles(new HashSet<Role>(Arrays.asList(userAdminRole)));  // Cargo un nuevo "ADMIN" en la lista 
        
        System.out.println("USer is ready: " + user);
		userRepository.save(user);  // guardo el usuario ( nuevo ADMIN )
	}
	
	
}
