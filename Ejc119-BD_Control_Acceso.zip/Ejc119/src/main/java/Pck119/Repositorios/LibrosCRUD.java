package Pck119.Repositorios;

import org.springframework.data.repository.CrudRepository;

import Pck119.Entidades.Libros;

public interface LibrosCRUD extends CrudRepository<Libros, Long>{

	

}
