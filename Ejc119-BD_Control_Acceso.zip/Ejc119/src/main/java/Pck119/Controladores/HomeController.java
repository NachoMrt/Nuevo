package Pck119.Controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import Pck119.Entidades.User;
import Pck119.Servicios.UserService;


@Controller
public class HomeController {

	
	 private UserService userService;
     
	 public HomeController (UserService userService) {
		  this.userService = userService;
	  }
	  
	  @GetMapping("/login")
	  public String loginPage() {
	    return "admin/login";
	  }
	  
	  @GetMapping("/register")
	  public String registerPage(Model model) {
	    model.addAttribute("user", new User());
	    return "admin/register";
	  }
	  
	  @PostMapping(value = "/register")
	  public String createNewUser(User user, BindingResult bindingResult, Model model) {
		 
		  User userExists = userService.findUserByUsername(user.getUsername());
		  if (userExists != null) {
			  model.addAttribute("message", "Username YA registrado");
			  return "admin/register";
		  }  else {
			  userService.saveUser(user);
			  model.addAttribute("message", "Registrado con exito. Gracias por login bro !!");
			  return "admin/login";
		  }
	  }
	  
	  @GetMapping("/admin")
	  public String adminPage() {
	    return "admin/home";
	  } 
	  
	  @GetMapping("/adminErr")
	  public String adminPageErr() {
	    return "admin/errorAdmin";
	  } 

	  
}
