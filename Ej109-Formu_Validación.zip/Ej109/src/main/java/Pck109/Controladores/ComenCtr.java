package Pck109.Controladores;

import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import Pck109.Entidades.Comment;

@Controller
public class ComenCtr {

	@GetMapping("/")
	  public String greetingForm() {
	    return "index";
	  }
	  
	  @GetMapping("/comment")
	  public String commentForm(Model model) {
	  	Comment comment = new Comment();
	    model.addAttribute("comment", comment);    
	    return "comment";
	  }

	  @PostMapping("/comment")
	  public String commentSubmit(@Valid Comment comment, 
			  						BindingResult bindingResult) {
	    if (bindingResult.hasErrors()) {
	    	System.err.println("Error in validation " 
	    			+ bindingResult.getAllErrors());
	      return "comment";
	    }
	    return "commentSaved";
	  }
	
}
