package Pck109;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej109ApplicationTests {

	@Test
	void contextLoads() {
	}

}
