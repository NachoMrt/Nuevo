package Pck104;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej104Application {

	public static void main(String[] args) {
		SpringApplication.run(Ej104Application.class, args);
	}

}
