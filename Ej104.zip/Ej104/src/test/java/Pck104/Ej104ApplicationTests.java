package Pck104;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej104ApplicationTests {

	@Test
	void contextLoads() {
	}

}
