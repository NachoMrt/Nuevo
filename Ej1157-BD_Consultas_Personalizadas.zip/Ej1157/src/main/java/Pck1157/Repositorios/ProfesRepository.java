package Pck1157.Repositorios;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import Pck1157.Entidades.Profesores;
import net.bytebuddy.asm.Advice.OffsetMapping.Sort;

public interface ProfesRepository extends JpaRepository<Profesores, Long> {  // o CrudRepository
	
	List<Profesores> findByNombreP(String nombreP);
    List<Profesores> findByEdadPGreaterThan(Integer edadP);
    List<Profesores> findByEdadPLessThan(Integer edadP); 
    // Con OrderBy se puede ORDENAR los resultados de la busqueda
    List<Profesores> findByEdadPGreaterThanOrderByNombrePAsc(Integer edadP);
    long countByCursoP(String cursoP);  // Se puede utilizar el countBy y como resultado da el número de busquedas encontadas con éxito
   
    // Obligado poner:
    // @Transactional indica que son simplemente metadatos que pueden ser consumidos por alguna infraestructura de tiempo de ejecución. 
    // El método debe estar anotado con @Modifying si no Spring Data JPA interpretará que se trata de una select y la ejecutará como tal.
    @Transactional
    @Modifying
    @Query("DELETE FROM Profesores WHERE cursoP=:cursoP")
    int deleteByCursoP(@Param("cursoP") String cursoP);  
    @Transactional   // Obligado ponerlo
    int removeByEdadP(Integer edadP);  // Igual con: deleteBy


}
