package Pck1157.Controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import Pck1157.Repositorios.ProfesRepository;

@Controller
public class ProfesoresCtrl {

	@Autowired
	private ProfesRepository pfrp;
	
	// Listado de TODOS los registros
    @RequestMapping("/profes")
    public String listaProfes(ModelMap mp){
        mp.put("profesores", pfrp.findAll());
        return "Profes/listaPrf";
    }
    
    // Busca por nombre introducido
	@RequestMapping("/nombreP")
	public String nombreP(@RequestParam("np") String np, ModelMap mp) {
		if( (pfrp.findByNombreP(np)).size() == 0 ) {
			return "Profes/errorP";	
		} else {
			mp.put("profesores", pfrp.findByNombreP(np));
			return "Profes/encontradosPrf";
		}
	}
	
	 // Busca por nombre introducido de manera ORDENADA
	@RequestMapping("/edadPOrd")
	public String nombrePOrd(@RequestParam("npOrd") Integer npOrd, ModelMap mp) {
		if( (pfrp.findByEdadPGreaterThanOrderByNombrePAsc(npOrd)).size() == 0 ) {
			return "Profes/errorP";	
		} else {
			mp.put("profesores", pfrp.findByEdadPGreaterThanOrderByNombrePAsc(npOrd));
			return "Profes/encontradosPrf";
		}
	}
	
	// Busca por edad introducida MAYOR que
	@RequestMapping("/edadP")
	public String edadP(@RequestParam("edp") Integer edp, ModelMap mp) {
		if( (pfrp.findByEdadPGreaterThan(edp)).size() == 0 ) {
			return "Profes/errorP";	
		} else {
			mp.put("profesores", pfrp.findByEdadPGreaterThan(edp));
			return "Profes/encontradosPrf";
		}
	}
	
	// Busca por edad introducida MENOR que
	@RequestMapping("/edadMnP")
	public String edadMnP(@RequestParam("edMp") Integer edMp, ModelMap mp) {
		if( (pfrp.findByEdadPLessThan(edMp)).size() == 0 ) {
			return "Profes/errorP";	
		} else {
			mp.put("profesores", pfrp.findByEdadPLessThan(edMp));
			return "Profes/encontradosPrf";
		}
	}
	
	// Borra por curso introducido
	@RequestMapping("/cursoDlt")
	public String curDtl(@RequestParam("curP") String curP, ModelMap mp) {
		if( (pfrp.deleteByCursoP(curP)) == 0 ) {
			return "Profes/errorP";	
		} else {
			pfrp.deleteByCursoP(curP);
			return "Profes/cantPrf";
		}
	}
	
	// Borra por curso introducido
	@RequestMapping("/cursoDltRv")
	public String curDtlRv(@RequestParam("curDltRv") Integer curDltRv, ModelMap mp) {
		if( (pfrp.removeByEdadP(curDltRv)) == 0 ) {
			return "Profes/errorP";	
		} else {
			pfrp.removeByEdadP(curDltRv);
			return "Profes/cantPrf";
		}
	}
	
	
}
