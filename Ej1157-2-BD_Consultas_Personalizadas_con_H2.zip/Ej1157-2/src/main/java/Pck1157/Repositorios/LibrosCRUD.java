package Pck1157.Repositorios;

import org.springframework.data.repository.CrudRepository;

import Pck1157.Entidades.Libros;

public interface LibrosCRUD extends CrudRepository<Libros, Long>{

	

}
