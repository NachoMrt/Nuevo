package Pck1157.Entidades;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Profesores {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ID;
	@NotNull
	@Size(min = 1, max = 50)
	private String nombreP;
	@NotNull
	@Size(min = 1, max = 100)
	private String cursoP;
	@NotNull
	private Integer edadP;
	
	public Profesores(@NotNull @Size(min = 1, max = 100) String nombreP,
			@NotNull @Size(min = 1, max = 100) String cursoP, @NotNull int edadP) {
		super();
		this.nombreP = nombreP;
		this.cursoP = cursoP;
		this.edadP = edadP;
	}
	public Profesores() { }
	
	public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	
	public String getNombreP() {
		return nombreP;
	}
	public void setNombreP(String nombreP) {
		this.nombreP = nombreP;
	}
	
	public String getCursoP() {
		return cursoP;
	}
	public void setCursoP(String cursoP) {
		this.cursoP = cursoP;
	}
	
	public int getEdadP() {
		return edadP;
	}
	public void setEdadP(int edadP) {
		this.edadP = edadP;
	}
	
	
}
