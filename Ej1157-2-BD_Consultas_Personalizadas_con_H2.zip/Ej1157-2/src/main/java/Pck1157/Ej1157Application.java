package Pck1157;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej1157Application {
	 
	public static void main(String[] args) {
		SpringApplication.run(Ej1157Application.class, args);
	}

	
	
}
