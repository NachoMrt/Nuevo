insert into profesores (ID, nombreP, cursoP, edadP) values (1,'Carlos','Java',122);
insert into profesores (ID, nombreP, cursoP, edadP) values (2,'Ana','Spring',22);
insert into profesores (ID, nombreP, cursoP, edadP) values (3,'Juan Carlos','PHP',43);
insert into profesores (ID, nombreP, cursoP, edadP) values (4,'Luis','HTML',80);

