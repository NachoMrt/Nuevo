package Pck1133;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej1133Application {

	public static void main(String[] args) {
		SpringApplication.run(Ej1133Application.class, args);
	}

}
