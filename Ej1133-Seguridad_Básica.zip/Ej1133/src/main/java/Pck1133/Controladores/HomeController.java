package Pck1133.Controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class HomeController {
	
	@GetMapping("/")
	public String inicio() {
		return "index";
	}

	@GetMapping("/public")
	public String publicPage() {
		return "public";
	}
	
	@GetMapping("/protected")
	    public String protectedPage() {
	        return "protected";
	 }
	
	@GetMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	@GetMapping("/pepit")
	public String loginPag2() {
		return "pepito";
	}
	   	
	
}
