package Pck120.Servicios;

import java.util.Arrays;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import Pck120.Entidades.Role;
import Pck120.Entidades.User;
import Pck120.Repositorios.RoleRepository;
import Pck120.Repositorios.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
    private RoleRepository roleRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	public User findUserByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	public User findUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}
	
	public void saveUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));  // codifica password
        user.setEnabled(true);  // pone propiedad enabled a true
        
        Role userAdminRole = roleRepository.findByRole("ADMIN");  // Busca rol "ADMIN"
        user.setRoles(new HashSet<Role>(Arrays.asList(userAdminRole)));  // Cargo un nuevo "ADMIN" en la lista 
        
        System.out.println("USer is ready: " + user);
		userRepository.save(user);  // guardo el usuario ( nuevo ADMIN )
	}
	
	
}
