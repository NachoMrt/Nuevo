package Pck120.Servicios;

import Pck120.Entidades.User;

public interface UserService {

	public User findUserByUsername(String username);
	public User findUserByEmail(String email);
	public void saveUser(User user);  // Método para guardar Usuarios ( administradores )
	
}
