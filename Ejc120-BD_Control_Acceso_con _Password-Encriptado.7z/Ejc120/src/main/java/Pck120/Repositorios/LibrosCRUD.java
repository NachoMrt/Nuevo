package Pck120.Repositorios;

import org.springframework.data.repository.CrudRepository;

import Pck120.Entidades.Libros;

public interface LibrosCRUD extends CrudRepository<Libros, Long>{

	

}
