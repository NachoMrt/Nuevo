package Pck1152;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej1152ApplicationTests {

	@Test
	void contextLoads() {
	}

}
