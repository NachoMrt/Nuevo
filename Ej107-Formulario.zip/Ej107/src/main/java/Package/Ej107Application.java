package Package;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej107Application {

	public static void main(String[] args) {
		SpringApplication.run(Ej107Application.class, args);
	}

}
