package Package;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej106ApplicationTests {

	@Test
	void contextLoads() {
	}

}
