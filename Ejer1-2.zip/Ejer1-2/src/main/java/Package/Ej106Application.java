package Package;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ej106Application {

	public static void main(String[] args) {
		SpringApplication.run(Ej106Application.class, args);
	}

}
