package Package.Controladores;

import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SampleGet {

	 @GetMapping("/say")
	  public String saySomething(@RequestParam(value="something", required=false, 
	  								  defaultValue="Hello") String something, Model model) {
		  
	    model.addAttribute("something", something);
	    return "say";
	  }
	  
	  
	  @GetMapping("/add")
	  public String add(@RequestParam(value="a", required=true, 
	  								defaultValue="0") Integer a,
	  					@RequestParam(value="b", required=true, 
	  								  defaultValue="0") Integer b,
	  					Model model) {
		  
	    int result = a + b;
	  	model.addAttribute("result", result);
	    return "add";
	  }
	  
	  @GetMapping("/Otra")
	  public String sayOtraOpc(@RequestParam(value="name") Optional<String> name, Model model) {		  
		  model.addAttribute("nombre", name.orElse("Nacho"));
		  return "OtraOpc";
	  }
	  
	 @GetMapping("/Operacion/{name}")
	  public String mandarPath(@PathVariable String name, Model model) {
		  model.addAttribute("nombre", name);
		  return "Operacion";
	  }
	
	
}
