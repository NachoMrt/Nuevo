package Pck119.Seguridad;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class LamePasswordEncoder implements PasswordEncoder {

	// Con cambiar esta clase por otra que lo codifique realmente bastaría ( los métodos )
	@Override
	public String encode(CharSequence rawPassword) {  // NO codifica realmente el password
		return rawPassword.toString();
	}

	@Override
	public boolean matches(CharSequence rawPassword, String encodedPassword) {  // verifica ( empareja ) la contraseña
		return rawPassword.toString().equals(encodedPassword);
	}
	
	
}
