insert into libros (ID, titulo, genero, autor) values (1,'Don Quijote','Clasico','Cervantes');
insert into libros (ID, titulo, genero, autor) values (2,'NoSE','Novela','Desconicido');
insert into libros (ID, titulo, genero, autor) values (3,'Historia de aqui','Humor','Forges');

insert into role (id, role) values (1,'ANONYMOUS');
insert into role (id, role) values (2,'USER');
insert into role (id, role) values (3,'ADMIN');

insert into user (id, username, email, password, enabled) values (1,'nacho','nnnm@gmail.com','19088',1);
insert into user (id, username, email, password, enabled) values (2,'curso','otro@gmail.com','22334',1);




