package Pck110;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej110ApplicationTests {

	@Test
	void contextLoads() {
	}

}
